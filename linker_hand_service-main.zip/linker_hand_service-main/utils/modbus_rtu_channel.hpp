#ifndef _UT_MODBUS_RTU_CHANNEL_H_
#define _UT_MODBUS_RTU_CHANNEL_H_

#include <string>
#include <vector>
#include <mutex>
#include <chrono>
#include <memory>

struct sp_port;

namespace unitree
{
namespace robot
{

class ModbusRTUChannel {
public:
    ModbusRTUChannel(const std::string& port, int baudrate = 4000000, int slave_id = 0x27);
    ~ModbusRTUChannel();

    bool connect();
    void disconnect();
    bool isConnected() const;

    std::vector<int> readRegisters(int address, int count);
    void writeRegisters(int address, const std::vector<int>& values);

    std::string getPort() const { return port_name_; }
    int getSlaveId() const { return slave_id_; }

private:
    std::string port_name_;
    int baudrate_;
    int slave_id_;
    struct sp_port* port_;
    int fd_;
    bool connected_;
    mutable std::mutex mutex_;

    void checkConnection();

    // Modbus RTU helpers
    uint16_t calcCRC16(const uint8_t* data, size_t len);
    void sendFrame(const uint8_t* txbuf, size_t txlen);
    void recvFrame(uint8_t* rxbuf, size_t expected_len);
};

} // namespace robot
} // namespace unitree

#endif // _UT_MODBUS_RTU_CHANNEL_H_
