#pragma once

#include <string>
#include <vector>
#include <algorithm>
#include <iostream>

class ArgParser {
public:
    ArgParser(int argc, char* argv[]) {
        for (int i = 1; i < argc; ++i) {
            tokens.push_back(std::string(argv[i]));
        }
    }

    /**
     * @brief Get the value of a command line option (e.g., -i value or --interface value)
     */
    std::string getOption(const std::string& option, const std::string& defaultValue = "") const {
        auto it = std::find(tokens.begin(), tokens.end(), option);
        if (it != tokens.end() && ++it != tokens.end()) {
            return *it;
        }
        return defaultValue;
    }

    /**
     * @brief Check if a command line option exists
     */
    bool hasOption(const std::string& option) const {
        return std::find(tokens.begin(), tokens.end(), option) != tokens.end();
    }

    /**
     * @brief Get the raw argument at the specified index (0-based, excluding program name)
     */
    std::string getArgument(size_t index, const std::string& defaultValue = "") const {
        if (index < tokens.size()) {
            return tokens[index];
        }
        return defaultValue;
    }

    /**
     * @brief Get the number of arguments (excluding program name)
     */
    size_t count() const {
        return tokens.size();
    }

private:
    std::vector<std::string> tokens;
};
