#include "modbus_rtu_channel.hpp"
#include "utils/bp_logger.hpp"
#include <cstring>
#include <stdexcept>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <linux/serial.h>
#include <libserialport.h>

namespace unitree
{
namespace robot
{

ModbusRTUChannel::ModbusRTUChannel(const std::string& port, int baudrate, int slave_id)
    : port_name_(port), baudrate_(baudrate), slave_id_(slave_id), port_(nullptr), fd_(-1), connected_(false) {
}

ModbusRTUChannel::~ModbusRTUChannel() {
    disconnect();
}

bool ModbusRTUChannel::connect() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (connected_) return true;

    BP_LOG_I("MODBUS", "Connecting to ", port_name_, " at ", baudrate_, " baud, slave ID: ", slave_id_);

    auto cleanup = [this]() {
        if (port_) {
            sp_close(port_);
            sp_free_port(port_);
            port_ = nullptr;
            fd_ = -1;
        }
    };

    enum sp_return ret = sp_get_port_by_name(port_name_.c_str(), &port_);
    if (ret != SP_OK) {
        BP_LOG_E("MODBUS", "Failed to get port by name: ", sp_last_error_message());
        cleanup();
        return false;
    }

    ret = sp_open(port_, SP_MODE_READ_WRITE);
    if (ret != SP_OK) {
        BP_LOG_E("MODBUS", "Failed to open port: ", sp_last_error_message());
        cleanup();
        return false;
    }

    if (sp_set_baudrate(port_, baudrate_) != SP_OK ||
        sp_set_bits(port_, 8) != SP_OK ||
        sp_set_parity(port_, SP_PARITY_NONE) != SP_OK ||
        sp_set_stopbits(port_, 1) != SP_OK ||
        sp_set_flowcontrol(port_, SP_FLOWCONTROL_NONE) != SP_OK) {
        BP_LOG_E("MODBUS", "Failed to configure port: ", sp_last_error_message());
        cleanup();
        return false;
    }

    // Enable ASYNC_LOW_LATENCY for CH343
    if (sp_get_port_handle(port_, &fd_) == SP_OK && fd_ >= 0) {
        struct serial_struct serial;
        if (ioctl(fd_, TIOCGSERIAL, &serial) == 0) {
            serial.flags |= ASYNC_LOW_LATENCY;
            if (ioctl(fd_, TIOCSSERIAL, &serial) == 0) {
                BP_LOG_I("MODBUS", "Low latency mode enabled.");
            }
        }
    }

    sp_flush(port_, SP_BUF_BOTH);
    connected_ = true;
    BP_LOG_I("MODBUS", "Connected successfully.");
    return true;
}

void ModbusRTUChannel::disconnect() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (port_) {
        sp_close(port_);
        sp_free_port(port_);
        port_ = nullptr;
        fd_ = -1;
    }
    connected_ = false;
}

bool ModbusRTUChannel::isConnected() const {
    return connected_;
}

void ModbusRTUChannel::checkConnection() {
    if (!connected_) {
        throw std::runtime_error("Not connected to modbus device");
    }
}

uint16_t ModbusRTUChannel::calcCRC16(const uint8_t* data, size_t len) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (int j = 0; j < 8; ++j) {
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
        }
    }
    return crc;
}

void ModbusRTUChannel::sendFrame(const uint8_t* txbuf, size_t txlen) {
    int ret = sp_nonblocking_write(port_, txbuf, txlen);
    if (ret < 0 || static_cast<size_t>(ret) != txlen) {
        throw std::runtime_error(std::string("Modbus write failed: ") + sp_last_error_message());
    }
    sp_drain(port_);
}

void ModbusRTUChannel::recvFrame(uint8_t* rxbuf, size_t expected_len) {
    size_t total = 0;
    while (total < expected_len) {
        int ret = sp_blocking_read_next(port_, rxbuf + total, expected_len - total, 100);
        if (ret < 0) {
            throw std::runtime_error(std::string("Modbus read failed: ") + sp_last_error_message());
        }
        if (ret == 0) {
            throw std::runtime_error("Modbus read timeout");
        }
        total += ret;
    }
}

// Modbus RTU frame structures for better readability
struct ModbusReadReq {
    uint8_t slave_id;
    uint8_t func_code;        // 0x04
    uint8_t addr_hi, addr_lo;
    uint8_t count_hi, count_lo;
    uint8_t crc_hi, crc_lo;
};

struct ModbusWriteReq {
    uint8_t slave_id;
    uint8_t func_code;        // 0x10
    uint8_t addr_hi, addr_lo;
    uint8_t count_hi, count_lo;
    uint8_t byte_count;
    uint8_t data[36];         // max 18 registers * 2 bytes
    uint8_t crc_hi, crc_lo;
};

struct ModbusResp {
    uint8_t slave_id;
    uint8_t func_code;
    union {
        uint8_t byte_count;
        uint8_t count_hi;
    };
    union {
        uint8_t count_lo;
        uint8_t data[256];
    };
    uint8_t crc_hi, crc_lo;
};

std::vector<int> ModbusRTUChannel::readRegisters(int address, int count) {
    std::lock_guard<std::mutex> lock(mutex_);
    checkConnection();

    ModbusReadReq req = {};
    req.slave_id = slave_id_;
    req.func_code = 0x04;
    req.addr_hi = address >> 8;
    req.addr_lo = address & 0xFF;
    req.count_hi = count >> 8;
    req.count_lo = count & 0xFF;
    uint16_t crc = calcCRC16(reinterpret_cast<uint8_t*>(&req), 6);
    req.crc_hi = crc & 0xFF;
    req.crc_lo = crc >> 8;

    sendFrame(reinterpret_cast<uint8_t*>(&req), 8);

    ModbusResp resp = {};
    recvFrame(reinterpret_cast<uint8_t*>(&resp), 5 + count * 2);

    crc = calcCRC16(reinterpret_cast<uint8_t*>(&resp), 3 + count * 2);
    if (crc != (resp.data[count * 2] | (resp.data[count * 2 + 1] << 8))) {
        throw std::runtime_error("Modbus CRC mismatch");
    }
    if (resp.slave_id != slave_id_ || resp.func_code != 0x04) {
        throw std::runtime_error("Modbus invalid response");
    }

    std::vector<int> result(count);
    for (int i = 0; i < count; ++i) {
        result[i] = (resp.data[i * 2] << 8) | resp.data[i * 2 + 1];
    }
    return result;
}

void ModbusRTUChannel::writeRegisters(int address, const std::vector<int>& values) {
    std::lock_guard<std::mutex> lock(mutex_);
    checkConnection();

    int count = values.size();
    ModbusWriteReq req = {};
    req.slave_id = slave_id_;
    req.func_code = 0x10;
    req.addr_hi = address >> 8;
    req.addr_lo = address & 0xFF;
    req.count_hi = count >> 8;
    req.count_lo = count & 0xFF;
    req.byte_count = count * 2;
    for (int i = 0; i < count; ++i) {
        req.data[i * 2] = values[i] >> 8;
        req.data[i * 2 + 1] = values[i] & 0xFF;
    }
    uint16_t crc = calcCRC16(reinterpret_cast<uint8_t*>(&req), 7 + count * 2);
    req.data[count * 2] = crc & 0xFF;
    req.data[count * 2 + 1] = crc >> 8;

    sendFrame(reinterpret_cast<uint8_t*>(&req), 9 + count * 2);

    ModbusResp resp = {};
    recvFrame(reinterpret_cast<uint8_t*>(&resp), 8);

    crc = calcCRC16(reinterpret_cast<uint8_t*>(&resp), 6);
    if (crc != (resp.crc_hi | (resp.crc_lo << 8))) {
        throw std::runtime_error("Modbus CRC mismatch");
    }
    if (resp.slave_id != slave_id_ || resp.func_code != 0x10) {
        throw std::runtime_error("Modbus invalid response");
    }
}

} // namespace robot
} // namespace unitree
