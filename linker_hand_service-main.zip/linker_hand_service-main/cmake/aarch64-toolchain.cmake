# CMake toolchain file for cross-compiling to aarch64 on Ubuntu
# -------------------------------------------------------------

# Target system specification
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR aarch64)

# Sysroot path
set(CMAKE_SYSROOT "")

# Specify the cross-compiler
set(CMAKE_C_COMPILER aarch64-linux-gnu-gcc)
set(CMAKE_CXX_COMPILER aarch64-linux-gnu-g++)

# Set the resource file compiler
set(CMAKE_RC_COMPILER aarch64-linux-gnu-windres)

# Configure the find commands to search in the sysroot
# This prevents CMake from finding and using host system libraries.
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
