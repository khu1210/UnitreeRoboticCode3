<div align="center">
  <h1 align="center">
    <a href="https://www.unitree.com" target="_blank">Linker Hand Service</a>
  </h1>
  <p align="center">
    <a> English </a> | <a href="README_zh-CN.md">中文</a> </a>
  </p>
  <a href="https://www.unitree.com/" target="_blank">
    <img src="https://www.unitree.com/images/0079f8938336436e955ea3a98c4e1e59.svg" alt="Unitree LOGO" width="15%">
  </a>
</div>

# 0. 📖 Introduction

The G1 can be equipped with [Linkerbot](https://linkerbot.cn/index)'s [O6 Dexterous Hand](https://document.linkeros.cn/developer/78), which features 6 degrees of freedom.

<p align="center">
  <img src=".github/images/icon-o6.png" alt="Linker Hand O6" width="25%">
</p>

The dexterous hand is controlled via serial communication (Modbus RTU).

In this repository, we convert serial messages into DDS messages so they can be used with [unitree_sdk2](https://github.com/unitreerobotics/unitree_sdk2).

- Each hand (left or right) is controlled by a USB-to-serial device, and each generates a pair of topics: `rt/linker/(left or right)/(cmd or state)`.

- The position of the fingers are normalized to the [0, 1] range. Where `0` represents fingers open (extended), and `1` represents fingers closed (bent).

- The speed and torque are also normalized to the [0, 1] range. Where `0` represents minimum value, and `1` represents maximum value.

- It is recommended to set the speed of all fingers to 1.0.

- The finger indices are mapped as follows: ["Thumb", "Thumb Abduction", "Index", "Middle", "Ring", "Little"].

# 1. 📦 Installation

```bash
# at user development computing unit PC2 (NVIDIA Jetson Orin NX board)
sudo apt install libmodbus-dev
cd ~
git clone https://github.com/unitreerobotics/linker_hand_service
cd linker_hand_service
./build.sh
```

# 2. 🚀 Launch

```bash
cd ~/linker_hand_service/deploy/bin
# Run `sudo ./linker_hand_service -h` for details.

# start server
sudo ./linker_hand_server

# at another terminal, run test examples
# Normally, you should see the dexterous hand repeatedly perform the actions of making a fist and opening.

# test
cd ~/linker_hand_service/deploy/bin
sudo ./test_linker_hand_server
```

# 3. 🚀🚀🚀 Automatic Startup Service

After completing the above setup and configuration, and successfully testing `test_linker_hand_server`, you can configure the linker hand service to start automatically on system boot by running the following script:

```bash
cd ~/linker_hand_service
bash setup_autostart.sh
```

Follow the prompts in the script to complete your configuration.

### Service Management Commands

After setup, you can manage the service with:

```bash
sudo systemctl status linker_hand.service     # Check status
sudo journalctl -u linker_hand.service -f     # View logs in real-time
sudo systemctl stop linker_hand.service       # Stop service
sudo systemctl restart linker_hand.service    # Restart service
sudo systemctl disable linker_hand.service    # Disable auto-start on boot
```

# ❓ FAQ

1. Error when `make`:

   If the error mentions that the unitree_sdk2 headfile could not be found. First compile and install unitree_sdk2:

   ```bash
   cd ~
   git clone https://github.com/unitreerobotics/unitree_sdk2
   cd unitree_sdk2
   mkdir build & cd build
   cmake ..
   sudo make install
   ```

