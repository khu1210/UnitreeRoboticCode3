<div align="center">
  <h1 align="center">
    <a href="https://www.unitree.com" target="_blank">Linker Hand Service</a>
  </h1>
  <p align="center">
    <a href="README.md"> English </a> | <a>中文</a> </a>
  </p>
  <a href="https://www.unitree.com/" target="_blank">
    <img src="https://www.unitree.com/images/0079f8938336436e955ea3a98c4e1e59.svg" alt="Unitree LOGO" width="15%">
  </a>
</div>


# 0. 📖 介绍

G1 可以搭载[灵心巧手](https://linkerbot.cn/index)的 [仿生灵巧手 O6](https://document.linkeros.cn/developer/78)，它具有 6 个自由度。

<p align="center">
  <img src=".github/images/icon-o6.png" alt="Linker Hand O6" width="25%">
</p>

灵巧手通过串口（Modbus RTU）进行控制。

在本仓库中，我们将串口消息转换成 DDS 消息，以便可以与 [unitree_sdk2](https://github.com/unitreerobotics/unitree_sdk2) 配合使用。

* 每只手（左或右）通过一个 USB-转串口设备进行控制，并各自生成一对主题：`rt/linker/(left or right)/(cmd or state)`。

* 手指的位置被归一化到 [0, 1] 的范围。其中 `0` 表示手指张开（伸直），`1` 表示手指闭合（弯曲）。

* 速度和扭矩也被归一化到 [0, 1] 的范围。其中 `0` 表示最小值，`1` 表示最大值。

* 推荐将所有手指速度都设置为 1.0。

* 手指索引映射如下：["拇指", "拇指副指", "食指", "中指", "无名指", "小指"]。

# 1. 📦 安装

```bash
# 在用户开发计算单元 PC2（NVIDIA Jetson Orin NX 板）上
sudo apt install libmodbus-dev
cd ~
git clone https://github.com/unitreerobotics/linker_hand_service
cd linker_hand_service
./build.sh
```

# 2. 🚀 启动

```bash
cd ~/linker_hand_service/deploy/bin
# 运行 `sudo ./linker_hand_service -h` 获取更多信息。

# 启动服务
sudo ./linker_hand_server

# 另一个终端，运行测试示例
# 正常情况下，你会看到灵巧手反复做握拳和张开动作。

# 测试
cd ~/linker_hand_service/deploy/bin
sudo ./test_linker_hand_server
```

# 3. 🚀🚀🚀 自动启动服务

完成上述安装配置并成功测试 `test_linker_hand_server` 后，可以通过运行以下脚本配置开机自动启动：

```bash
cd ~/linker_hand_service
bash setup_autostart.sh
```

按照脚本提示完成配置。

### 服务管理命令

配置完成后，可以使用以下命令管理服务：

```bash
sudo systemctl status linker_hand.service     # 查看状态
sudo journalctl -u linker_hand.service -f     # 实时查看日志
sudo systemctl stop linker_hand.service       # 停止服务
sudo systemctl restart linker_hand.service    # 重启服务
sudo systemctl disable linker_hand.service    # 禁用开机自启动
```

# ❓ 常见问题

1. `make` 出错：

   如果提示 unitree_sdk2 头文件未找到。先编译并安装 unitree_sdk2：

   ```bash
   cd ~
   git clone https://github.com/unitreerobotics/unitree_sdk2
   cd unitree_sdk2
   mkdir build & cd build
   cmake ..
   sudo make install
   ```

