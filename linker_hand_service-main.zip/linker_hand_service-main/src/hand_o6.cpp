#include "hand_o6.hpp"
#include "utils/bp_logger.hpp"
#include <filesystem>
#include <iostream>
#include <thread>

namespace unitree
{
namespace robot
{

HandO6::HandO6(const std::string& port, int baudrate, int slave_id) {
    channel_ = std::make_unique<ModbusRTUChannel>(port, baudrate, slave_id);
}

HandO6::~HandO6() {
    disconnect();
}

bool HandO6::connect() {
    return channel_->connect();
}

void HandO6::disconnect() {
    channel_->disconnect();
}

bool HandO6::isConnected() const {
    return channel_->isConnected();
}

int HandO6::getSlaveId() const {
    return channel_->getSlaveId();
}

std::string HandO6::getPort() const {
    return channel_->getPort();
}

void HandO6::setControlState(const std::vector<int>& angles, const std::vector<int>& speeds, const std::vector<int>& torques) {
    std::vector<int> final_speeds = speeds;
    std::vector<int> final_torques = torques;
    
    if (final_speeds.empty()) {
        final_speeds.resize(6, 255); // Default max speed
    }

    if (final_torques.empty()) {
        final_torques.resize(6, 255); // Default max torque
    }
    
    if (angles.size() != 6 || final_torques.size() != 6 || final_speeds.size() != 6) {
        throw std::invalid_argument("All vectors must have size 6");
    }

    std::vector<int> all_values;
    all_values.reserve(18);
    all_values.insert(all_values.end(), angles.begin(), angles.end());
    all_values.insert(all_values.end(), final_torques.begin(), final_torques.end());
    all_values.insert(all_values.end(), final_speeds.begin(), final_speeds.end());

    channel_->writeRegisters(REG_WR_THUMB_PITCH, all_values);
}

HandO6::HandState HandO6::getAllState() {
    HandState state;
    try {
        std::vector<int> all_regs = channel_->readRegisters(REG_RD_CURRENT_THUMB_PITCH, 36);
        
        state.angles.assign(all_regs.begin(), all_regs.begin() + 6);
        state.torques.assign(all_regs.begin() + 6, all_regs.begin() + 12);
        state.speeds.assign(all_regs.begin() + 12, all_regs.begin() + 18);
        state.temperatures.assign(all_regs.begin() + 18, all_regs.begin() + 24);
        state.errors.assign(all_regs.begin() + 24, all_regs.begin() + 30);
        state.versions.assign(all_regs.begin() + 30, all_regs.begin() + 36);
    } catch (...) {
        throw;
    }
    return state;
}

HandO6::DeviceInfo HandO6::getDeviceInfo() {
    DeviceInfo info;
    int retries = 3;
    while (retries--) {
        try {
            BP_LOG_I("HAND", "Reading device info for slave ", getSlaveId(), " at ", getPort(), " (Retries left: ", retries, ")");
            // Read 15 registers from REG_RD_HAND_FREEDOM (30) to REG_RD_MECHANICAL_VERSION_L (44)
            std::vector<int> regs = channel_->readRegisters(REG_RD_HAND_FREEDOM, 15);
            info.freedom = regs[0];
            info.version = regs[1];
            info.number = std::to_string(regs[2]) + "." + std::to_string(regs[3]) + "." + std::to_string(regs[4]);
            info.direction = regs[5];
            info.hardware_version = std::to_string(regs[6]) + "." + std::to_string(regs[7]) + "." + std::to_string(regs[8]);
            info.software_version = std::to_string(regs[9]) + "." + std::to_string(regs[10]) + "." + std::to_string(regs[11]);
            info.mechanical_version = std::to_string(regs[12]) + "." + std::to_string(regs[13]) + "." + std::to_string(regs[14]);
            return info;
        } catch (const std::exception& e) {
            if (retries == 0) {
                BP_LOG_E("HAND", "Failed to get device info after retries: ", e.what());
                throw;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    }
    return info;
}



void HandO6::show_relax() {
    std::vector<int> angles = {255, 255, 255, 255, 255, 255};
    std::vector<int> speeds = {255, 255, 255, 255, 255, 255};
    std::vector<int> torques = {255, 255, 255, 255, 255, 255};
    setControlState(angles, speeds, torques);
}

void HandO6::show_fist() {
    std::vector<int> angles = {0, 0, 0, 0, 0, 0};
    std::vector<int> speeds = {255, 255, 255, 255, 255, 255};
    std::vector<int> torques = {255, 255, 255, 255, 255, 255};
    setControlState(angles, speeds, torques);
}


} // namespace robot
} // namespace unitree