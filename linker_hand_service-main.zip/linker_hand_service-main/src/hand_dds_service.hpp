#ifndef _UT_HAND_DDS_SERVICE_H_
#define _UT_HAND_DDS_SERVICE_H_

#include <unitree/robot/channel/channel_publisher.hpp>
// #include <unitree/dds_wrapper/common/Publisher.h>
#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/idl/go2/MotorCmds_.hpp>
#include <unitree/idl/go2/MotorStates_.hpp>
#include "hand_o6.hpp"
#include <string>
#include <thread>
#include <atomic>

namespace unitree
{
namespace robot
{

class HandDDSService {
public:
    HandDDSService(std::shared_ptr<HandO6> hand, const std::string& side);
    ~HandDDSService();

    void start();
    void stop();

private:
    std::shared_ptr<HandO6> hand_;
    std::string side_; // "left" or "right"
    std::atomic<bool> running_;
    std::thread state_thread_;

    // DDS
    using MotorCmdsMsg = unitree_go::msg::dds_::MotorCmds_;
    using MotorStatesMsg = unitree_go::msg::dds_::MotorStates_;

    unitree::robot::ChannelSubscriberPtr<MotorCmdsMsg> sub_cmd_;
    unitree::robot::ChannelPublisherPtr<MotorStatesMsg> pub_state_;

    void cmdCallback(const void* message);
    void stateLoop();

    // Publishing frequency for state messages (Hz). Change here to adjust rate.
    static constexpr uint32_t STATE_PUBLISH_HZ = 100;
    // Precomputed period in nanoseconds for convenience
    static constexpr uint32_t STATE_PERIOD_NS = 1000000000L / STATE_PUBLISH_HZ;

    // Helpers
    int normalizeToByte(float val);
    float byteToNormalize(int val);
};

} // namespace robot
} // namespace unitree

#endif // _UT_HAND_DDS_SERVICE_H_