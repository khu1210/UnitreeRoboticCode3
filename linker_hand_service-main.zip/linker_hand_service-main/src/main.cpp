#include <csignal>
#include <chrono>
#include <thread>
#include <vector>
#include <memory>
#include <iostream>
#include <filesystem>
#include <algorithm>

#include "utils/bp_logger.hpp"
#include "utils/arg_parser.hpp"
#include "hand_o6.hpp"
#include "hand_dds_service.hpp"


using namespace unitree::robot;



// ------------------ Globals ------------------
static std::atomic<bool> g_running{true};

// ------------------ Signal Handler ------------------
static void signalHandler(int signal) {
    BP_LOG_I("MAIN", "Received signal ", signal, ", shutting down...");
    g_running = false;
}

// ------------------ Utility Functions ------------------

/**
 * @brief Get list of available serial ports (/dev/ttyHAND* /dev/ttyUSB* /dev/ttyUN* )
 */
std::vector<std::string> getAvailableSerialPorts() {
    std::vector<std::string> ports;

    // Scan ttyHAND
    for (int i = 0; i < 10; ++i) {
        std::string p = "/dev/ttyHAND" + std::to_string(i);
        if (std::filesystem::exists(p)) ports.push_back(p);
    }

    // Scan ttyUSB
    for (int i = 0; i < 10; ++i) {
        std::string p = "/dev/ttyUSB" + std::to_string(i);
        if (std::filesystem::exists(p)) ports.push_back(p);
    }

    // Scan ttyUN*
    for (int i = 0; i < 5; ++i) {
        std::string p = "/dev/ttyUN" + std::to_string(i);
        if (std::filesystem::exists(p)) ports.push_back(p);
    }

    // Log available ports
    std::string port_list_str;
    for (const auto& p : ports) port_list_str += p + " ";
    BP_LOG_I("MAIN", "Available Serial Ports: ", port_list_str);
    
    return ports;
}

/**
 * @brief Try to connect to a hand on a specific port with a specific ID and baudrate
 */
std::shared_ptr<HandO6> tryConnectHand(const std::string& port, int baudrate, int slave_id) {
    try {
        HandO6::DeviceInfo info;
        auto hand = std::make_shared<HandO6>(port, baudrate, slave_id);
        if (hand->connect()) {
            // Verify connection by reading state
            try {
                info = hand->getDeviceInfo();

                BP_LOG_I("MAIN", "Found hand with ID ", slave_id, " at ", port, " (", baudrate, " baud)"
                  ". freedom: ", info.freedom, ", version: ", info.version, ", number: ", info.number, 
                  ", direction: ", info.direction, ", software_version: ", info.software_version, 
                  ", hardware_version: ", info.hardware_version);
                return hand;
            } catch (const std::exception& e) {
                // BP_LOG_D("MAIN", "Failed to get device info for ID ", slave_id, " at ", port, " (", baudrate, "): ", e.what());
                hand->disconnect();
            } catch (...) {
                hand->disconnect();
            }
        }
    } catch (...) {
        // Ignore connection errors
    }
    return nullptr;
}

/**
 * @brief Find a hand with a specific ID from a list of ports
 * Removes the used port from the list if found.
 */
std::shared_ptr<HandO6> findHand(std::vector<std::string>& ports, int slave_id, const std::string& hand_name) {
    for (auto it = ports.begin(); it != ports.end(); ++it) {
        std::string port = *it;
        
        BP_LOG_I("MAIN", "Checking ", port, " for ", hand_name, " (ID ", slave_id, ") at ", BAUDRATE_4M, " baud...");
        auto hand = tryConnectHand(port, BAUDRATE_4M, slave_id);
        if (hand) {
            BP_LOG_I("MAIN", "Found ", hand_name, " hand on ", port, " at ", BAUDRATE_4M, " baud");
            ports.erase(it); // Remove used port
            return hand;
        }
    }
    return nullptr;
}

// ------------------ Main ------------------

int main(int argc, char* argv[]) {
    // Signal handling
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    signal(SIGPIPE, SIG_IGN);

    // Initialize Logger
    bpLogger::getInstance().initialize(UT_DEFAULT_LOG_CONF_PATH);
    BP_LOG_I("MAIN", "Starting Linker Hand Service...");

    // The second argument (optional) is the network interface name/number.
    // If provided use it, otherwise initialize without specifying an interface.
    ArgParser parser(argc, argv);

    if (parser.hasOption("-h") || parser.hasOption("--help")) {
        std::cout << "Usage: " << argv[0] << " [network_interface]" << std::endl;
        std::cout << "Options:" << std::endl;
        std::cout << "  -h, --help       Show this help message and exit" << std::endl;
        std::cout << "Arguments:" << std::endl;
        std::cout << "  network_interface  Optional. The network interface name (e.g., eth0) or number." << std::endl;
        return 0;
    }

    std::string networkInterface = parser.getArgument(0);
    if (networkInterface.empty()) {
        ChannelFactory::Instance()->Init(0);
        BP_LOG_I("MAIN", "No network interface provided, using default DDS network settings.");
    } else {
        ChannelFactory::Instance()->Init(0, networkInterface);
        BP_LOG_I("MAIN", "Using network interface: ", networkInterface);
    }

    // Get available ports
    std::vector<std::string> available_ports = getAvailableSerialPorts();
    if (available_ports.empty()) {
        BP_LOG_E("MAIN", "No serial ports found!");
        return 0;
    }

    // Find Hands
    auto left_hand = findHand(available_ports, L_ID, "Left");
    auto right_hand = findHand(available_ports, R_ID, "Right");

    if (!left_hand && !right_hand) {
        BP_LOG_E("MAIN", "No hands detected. Exiting.");
        return 0;
    }

    // Start Services
    std::vector<std::shared_ptr<HandDDSService>> services;

    if (left_hand) {
        auto service = std::make_shared<HandDDSService>(left_hand, "left");
        service->start();
        services.push_back(service);
    }

    if (right_hand) {
        auto service = std::make_shared<HandDDSService>(right_hand, "right");
        service->start();
        services.push_back(service);
    }

    // Main Loop
    while (g_running) {
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }

    // Cleanup
    BP_LOG_I("MAIN", "Stopping services...");
    for (auto& service : services) {
        service->stop();
    }

    BP_LOG_I("MAIN", "Service stopped.");
    return 0;
}