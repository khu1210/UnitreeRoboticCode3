#ifndef _UT_HAND_O6_H_
#define _UT_HAND_O6_H_

#include <sys/types.h>
#include <vector>
#include <memory>
#include <string>
#include "utils/modbus_rtu_channel.hpp"

namespace unitree
{
namespace robot
{

// ------------------ Constants ------------------
// Linker Hand ID
constexpr uint8_t L_ID = 0x28; // Left Hand ID (40)
constexpr uint8_t R_ID = 0x27; // Right Hand ID (39)
constexpr uint32_t BAUDRATE_4M = 4000000;
// constexpr uint32_t BAUDRATE_4M = 115200;


class HandO6 {
public:
    struct HandState {
        std::vector<int> angles;
        std::vector<int> torques;
        std::vector<int> speeds;
        std::vector<int> temperatures;
        std::vector<int> errors;
        std::vector<int> versions;
    };

    struct DeviceInfo {
        int freedom;
        int version;
        std::string number;
        int direction;
        std::string hardware_version;
        std::string software_version;
        std::string mechanical_version;
    };

    HandO6(const std::string& port, int baudrate = 4000000, int slave_id = 0x27);
    ~HandO6();

    bool connect();
    void disconnect();
    bool isConnected() const;

    // test 
    void show_relax();
    void show_fist();

    // Control
    void setControlState(const std::vector<int>& angles, const std::vector<int>& speeds = {}, const std::vector<int>& torques = {});
    
    // State
    HandState getAllState();
    DeviceInfo getDeviceInfo();

    // Device Info
    int getSlaveId() const;
    std::string getPort() const;

private:
    std::unique_ptr<ModbusRTUChannel> channel_;

    /*
     * Register Address Map
     * Source: https://document.linkeros.cn/developer/91
     *
     * ------------------------------------------------------------------
     * Read Input Registers (Function Code 04, Read Only)
     * ------------------------------------------------------------------
     * REG_RD_CURRENT_THUMB_PITCH      = 0   // 大拇指弯曲角度（0-255，小=弯，大=伸）
     * REG_RD_CURRENT_THUMB_YAW        = 1   // 大拇指横摆角度（0-255，小=靠掌心，大=远离）
     * REG_RD_CURRENT_INDEX_PITCH      = 2   // 食指弯曲角度
     * REG_RD_CURRENT_MIDDLE_PITCH     = 3   // 中指弯曲角度
     * REG_RD_CURRENT_RING_PITCH       = 4   // 无名指弯曲角度
     * REG_RD_CURRENT_LITTLE_PITCH     = 5   // 小拇指弯曲角度
     * REG_RD_CURRENT_THUMB_TORQUE     = 6   // 大拇指弯曲转矩（0-255）
     * REG_RD_CURRENT_THUMB_YAW_TORQUE = 7   // 大拇指横摆转矩
     * REG_RD_CURRENT_INDEX_TORQUE     = 8   // 食指转矩
     * REG_RD_CURRENT_MIDDLE_TORQUE    = 9   // 中指转矩
     * REG_RD_CURRENT_RING_TORQUE      = 10  // 无名指转矩
     * REG_RD_CURRENT_LITTLE_TORQUE    = 11  // 小拇指转矩
     * REG_RD_CURRENT_THUMB_SPEED      = 12  // 大拇指弯曲速度（0-255）
     * REG_RD_CURRENT_THUMB_YAW_SPEED  = 13  // 大拇指横摆速度
     * REG_RD_CURRENT_INDEX_SPEED      = 14  // 食指速度
     * REG_RD_CURRENT_MIDDLE_SPEED     = 15  // 中指速度
     * REG_RD_CURRENT_RING_SPEED       = 16  // 无名指速度
     * REG_RD_CURRENT_LITTLE_SPEED     = 17  // 小拇指速度
     * REG_RD_THUMB_TEMP               = 18  // 大拇指弯曲温度（0-70℃）
     * REG_RD_THUMB_YAW_TEMP           = 19  // 大拇指横摆温度
     * REG_RD_INDEX_TEMP               = 20  // 食指温度
     * REG_RD_MIDDLE_TEMP              = 21  // 中指温度
     * REG_RD_RING_TEMP                = 22  // 无名指温度
     * REG_RD_LITTLE_TEMP              = 23  // 小拇指温度
     * REG_RD_THUMB_ERROR              = 24  // 大拇指错误码
     * REG_RD_THUMB_YAW_ERROR          = 25  // 大拇指横摆错误码
     * REG_RD_INDEX_ERROR              = 26  // 食指错误码
     * REG_RD_MIDDLE_ERROR             = 27  // 中指错误码
     * REG_RD_RING_ERROR               = 28  // 无名指错误码
     * REG_RD_LITTLE_ERROR             = 29  // 小拇指错误码
     * REG_RD_HAND_FREEDOM             = 30  // 版本号（与机械手标签相同）
     * REG_RD_HAND_VERSION             = 31  // 手版本
     * REG_RD_HAND_NUMBER_H            = 32  // 手编号 高字节
     * REG_RD_HAND_NUMBER_M            = 33  // 手编号 中字节
     * REG_RD_HAND_NUMBER_L            = 34  // 手编号 低字节
     * REG_RD_HAND_DIRECTION           = 35  // 手方向（左/右）
     * REG_RD_HARDWARE_VERSION_H       = 36  // 硬件版本 高字节
     * REG_RD_HARDWARE_VERSION_M       = 37  // 硬件版本 中字节
     * REG_RD_HARDWARE_VERSION_L       = 38  // 硬件版本 低字节
     * REG_RD_SOFTWARE_VERSION_H       = 39  // 软件版本 高字节
     * REG_RD_SOFTWARE_VERSION_M       = 40  // 软件版本 中字节
     * REG_RD_SOFTWARE_VERSION_L       = 41  // 软件版本 低字节
     * REG_RD_MECHANICAL_VERSION_H     = 42  // 机械版本 高字节
     * REG_RD_MECHANICAL_VERSION_M     = 43  // 机械版本 中字节
     * REG_RD_MECHANICAL_VERSION_L     = 44  // 机械版本 低字节
     *
     * ------------------------------------------------------------------
     * Write Holding Registers (Function Code 16, Read/Write)
     * ------------------------------------------------------------------
     * REG_WR_THUMB_PITCH      = 0   // 大拇指弯曲角度（0-255）
     * REG_WR_THUMB_YAW        = 1   // 大拇指横摆角度
     * REG_WR_INDEX_PITCH      = 2   // 食指弯曲角度
     * REG_WR_MIDDLE_PITCH     = 3   // 中指弯曲角度
     * REG_WR_RING_PITCH       = 4   // 无名指弯曲角度
     * REG_WR_LITTLE_PITCH     = 5   // 小拇指弯曲角度
     * REG_WR_THUMB_TORQUE     = 6   // 大拇指弯曲转矩
     * REG_WR_THUMB_YAW_TORQUE = 7   // 大拇指横摆转矩
     * REG_WR_INDEX_TORQUE     = 8   // 食指转矩
     * REG_WR_MIDDLE_TORQUE    = 9   // 中指转矩
     * REG_WR_RING_TORQUE      = 10  // 无名指转矩
     * REG_WR_LITTLE_TORQUE    = 11  // 小拇指转矩
     * REG_WR_THUMB_SPEED      = 12  // 大拇指弯曲速度
     * REG_WR_THUMB_YAW_SPEED  = 13  // 大拇指横摆速度
     * REG_WR_INDEX_SPEED      = 14  // 食指速度
     * REG_WR_MIDDLE_SPEED     = 15  // 中指速度
     * REG_WR_RING_SPEED       = 16  // 无名指速度
     * REG_WR_LITTLE_SPEED     = 17  // 小拇指速度
     */
    // Register Addresses
    static const int REG_RD_CURRENT_THUMB_PITCH = 0;
    static const int REG_RD_CURRENT_THUMB_TORQUE = 6;
    static const int REG_RD_CURRENT_THUMB_SPEED = 12;
    static const int REG_RD_THUMB_TEMP = 18;
    static const int REG_RD_THUMB_ERROR = 24;
    static const int REG_RD_HAND_FREEDOM = 30;
    static const int REG_RD_HAND_VERSION = 31;
    static const int REG_RD_HAND_NUMBER_H = 32;
    static const int REG_RD_HAND_NUMBER_M = 33;
    static const int REG_RD_HAND_NUMBER_L = 34;
    static const int REG_RD_HAND_DIRECTION = 35;
    static const int REG_RD_HARDWARE_VERSION_H = 36;
    static const int REG_RD_HARDWARE_VERSION_M = 37;
    static const int REG_RD_HARDWARE_VERSION_L = 38;
    static const int REG_RD_SOFTWARE_VERSION_H = 39;
    static const int REG_RD_SOFTWARE_VERSION_M = 40;
    static const int REG_RD_SOFTWARE_VERSION_L = 41;
    static const int REG_RD_MECHANICAL_VERSION_H = 42;
    static const int REG_RD_MECHANICAL_VERSION_M = 43;
    static const int REG_RD_MECHANICAL_VERSION_L = 44;

    static const int REG_WR_THUMB_PITCH = 0;
    static const int REG_WR_THUMB_TORQUE = 6;
    static const int REG_WR_THUMB_SPEED = 12;
};


} // namespace robot
} // namespace unitree

#endif // _UT_HAND_O6_H_