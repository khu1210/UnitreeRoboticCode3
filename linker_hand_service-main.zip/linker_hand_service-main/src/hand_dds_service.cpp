#include "hand_dds_service.hpp"
#include "utils/bp_logger.hpp"
#include <cmath>
#include <algorithm>
#include <iostream>
#include <chrono>
#include <time.h>

namespace unitree
{
namespace robot
{

HandDDSService::HandDDSService(std::shared_ptr<HandO6> hand, const std::string& side)
    : hand_(hand), side_(side), running_(false) {
    
    // Initialize DDS
    // Topic names: rt/linker/<left/right>/cmd, rt/linker/<left/right>/state
    std::string topic_cmd = "rt/linker/" + side_ + "/cmd";
    std::string topic_state = "rt/linker/" + side_ + "/state";

    BP_LOG_I("DDS", "Initializing DDS for ", side_, " hand.");
    BP_LOG_I("DDS", "Subscribing to ", topic_cmd);
    BP_LOG_I("DDS", "Publishing to ", topic_state);

    sub_cmd_.reset(new unitree::robot::ChannelSubscriber<MotorCmdsMsg>(topic_cmd));
    sub_cmd_->InitChannel(std::bind(&HandDDSService::cmdCallback, this, std::placeholders::_1), 1);

    pub_state_.reset(new unitree::robot::ChannelPublisher<MotorStatesMsg>(topic_state));
    pub_state_->InitChannel();
}

HandDDSService::~HandDDSService() {
    stop();
}

void HandDDSService::start() {
    if (running_) return;
    running_ = true;
    state_thread_ = std::thread(&HandDDSService::stateLoop, this);
}

void HandDDSService::stop() {
    running_ = false;
    if (state_thread_.joinable()) {
        state_thread_.join();
    }
}

int HandDDSService::normalizeToByte(float val) {
    // Assume val is [0, 1] -> [0, 255]
    // Clamp to [0, 1] first
    float clamped = std::max(0.0f, std::min(1.0f, val));
    return static_cast<int>(clamped * 255.0f);
}

float HandDDSService::byteToNormalize(int val) {
    // [0, 255] -> [0, 1]
    return static_cast<float>(val) / 255.0f;
}

void HandDDSService::cmdCallback(const void* message) {
    const MotorCmdsMsg* msg = (const MotorCmdsMsg*)message;
    
    if (!hand_ || !hand_->isConnected()) return;

    // HandO6 has 6 joints.
    // MotorCmds_ usually has a vector of commands.
    // We assume the first 6 commands correspond to the 6 joints.
    if (msg->cmds().size() < 6) {
        // BP_LOG_W("DDS", "Received MotorCmds with insufficient size: ", msg->cmds().size());
        return;
    }

    std::vector<int> angles(6);
    std::vector<int> speeds(6);
    std::vector<int> torques(6);

    for (int i = 0; i < 6; ++i) {
        // Upper layer: 0 (open) -> 1 (closed)
        // Device: 255 (open) -> 0 (closed)
        angles[i] = normalizeToByte(1.0f - msg->cmds()[i].q());
        speeds[i] = normalizeToByte(msg->cmds()[i].dq());

        // Map tau (torque) to torque
        // For now, let's assume tau is also normalized [0, 1] if provided, or just use a default.
        // If tau is 0, maybe we should use a default torque?
        // Let's assume tau is used if non-zero, otherwise default max.
        // Actually, HandO6 takes 0-255 for torque.
        torques[i] = normalizeToByte(msg->cmds()[i].tau()); 
        if (torques[i] == 0) torques[i] = 255;
    }

    try {
        hand_->setControlState(angles, speeds, torques);
    } catch (const std::exception& e) {
        BP_LOG_E("DDS", "Failed to set control state: ", e.what());
    }
}

// State publishing loop at configurable frequency (see STATE_PUBLISH_HZ in header)
void HandDDSService::stateLoop() {
    struct timespec next_time;
    clock_gettime(CLOCK_MONOTONIC, &next_time);

    while (running_) {
        next_time.tv_nsec += HandDDSService::STATE_PERIOD_NS;
        while (next_time.tv_nsec >= 1000000000) {
            next_time.tv_nsec -= 1000000000;
            next_time.tv_sec++;
        }

        if (hand_ && hand_->isConnected()) {
            try {
                auto hand_state = hand_->getAllState();
                
                MotorStatesMsg msg;
                msg.states().resize(6);
                
                for (int i = 0; i < 6; ++i) {            
                    // Device: 255 (open) -> 0 (closed)
                    // Upper layer: 0 (open) -> 1 (closed)
                    msg.states()[i].q() = 1.0f - byteToNormalize(hand_state.angles[i]);
                    msg.states()[i].dq() = byteToNormalize(hand_state.speeds[i]); // Approximate
                    msg.states()[i].tau_est() = byteToNormalize(hand_state.torques[i]); // Approximate
                    msg.states()[i].temperature() = hand_state.temperatures[i];
                    // msg.states()[i].reserve() = hand_state.errors[i]; // Store error in reserve?
                }

                pub_state_->Write(msg);

            } catch (const std::exception& e) {
                BP_LOG_E("DDS", "Failed to get/publish state: ", e.what());
            }
        }
        
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next_time, NULL);
    }
}


} // namespace robot
} // namespace unitree