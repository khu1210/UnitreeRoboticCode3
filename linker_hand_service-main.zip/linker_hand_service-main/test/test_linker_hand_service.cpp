#include <iostream>
#include <thread>
#include <chrono>
#include <array>
#include <vector>
#include <cmath>
#include <atomic>
#include <csignal>

#include <unitree/robot/channel/channel_publisher.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/robot/channel/channel_factory.hpp>
#include <unitree/idl/go2/MotorCmds_.hpp>
#include <unitree/idl/go2/MotorStates_.hpp>

using namespace unitree::robot;
using MotorCmdsMsg = unitree_go::msg::dds_::MotorCmds_;
using MotorStatesMsg = unitree_go::msg::dds_::MotorStates_;

std::atomic<bool> g_running{true};

void signalHandler(int signal) {
    std::cout << "Received signal " << signal << ", shutting down..." << std::endl;
    g_running = false;
}

void stateCallback(const void* message, const std::string& side) {
    const MotorStatesMsg* msg = (const MotorStatesMsg*)message;
    
    std::cout << "[" << side << "] State received. Joints: " << msg->states().size() << std::endl;
    for (size_t i = 0; i < msg->states().size() && i < 6; ++i) {
        std::cout << "  J" << i << ": q=" << msg->states()[i].q() 
                  << ", tau=" << msg->states()[i].tau_est() 
                  << ", temp=" << (int)msg->states()[i].temperature() << std::endl;
    }
}

int main(int argc, char** argv) {
    // Setup signal handler
    std::signal(SIGINT, signalHandler);

    (void)argc;
    (void)argv;

    ChannelFactory::Instance()->Init(0);

    // Create Publishers
    ChannelPublisherPtr<MotorCmdsMsg> pub_left_cmd;
    ChannelPublisherPtr<MotorCmdsMsg> pub_right_cmd;

    pub_left_cmd.reset(new ChannelPublisher<MotorCmdsMsg>("rt/linker/left/cmd"));
    pub_left_cmd->InitChannel();

    pub_right_cmd.reset(new ChannelPublisher<MotorCmdsMsg>("rt/linker/right/cmd"));
    pub_right_cmd->InitChannel();

    // Create Subscribers
    ChannelSubscriberPtr<MotorStatesMsg> sub_left_state;
    ChannelSubscriberPtr<MotorStatesMsg> sub_right_state;

    sub_left_state.reset(new ChannelSubscriber<MotorStatesMsg>("rt/linker/left/state"));
    sub_left_state->InitChannel(std::bind(stateCallback, std::placeholders::_1, "Left"), 1);

    sub_right_state.reset(new ChannelSubscriber<MotorStatesMsg>("rt/linker/right/state"));
    sub_right_state->InitChannel(std::bind(stateCallback, std::placeholders::_1, "Right"), 1);

    try {
        std::array<float, 6> positions{};

        auto hand_ctrl = [&](std::array<float, 6>& pos) {
            MotorCmdsMsg cmd_msg;
            cmd_msg.cmds().resize(6);

            for (int i = 0; i < 6; ++i) {
                cmd_msg.cmds()[i].q() = pos[i];
                cmd_msg.cmds()[i].dq() = 1.0f; // Max speed
                cmd_msg.cmds()[i].tau() = 1.0f; // Max torque
                cmd_msg.cmds()[i].kp() = 0.0f;
                cmd_msg.cmds()[i].kd() = 0.0f;
            }

            // Publish to both hands
            pub_left_cmd->Write(cmd_msg);
            pub_right_cmd->Write(cmd_msg);
        };

        while (g_running) {
            positions = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
            hand_ctrl(positions);
            for (int i = 0; i < 15 && g_running; ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            if (!g_running) {
                break;
            }

            positions = {0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};
            hand_ctrl(positions);
            for (int i = 0; i < 15 && g_running; ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            if (!g_running) {
                break;
            }

            positions = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};
            hand_ctrl(positions);
            for (int i = 0; i < 10 && g_running; ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
        }
    } catch (const std::exception& e) {
        std::cerr << "Runtime error: " << e.what() << std::endl;
        return 1;
    } catch (...) {
        std::cerr << "Runtime error: unknown" << std::endl;
        return 1;
    }

    return 0;
}
