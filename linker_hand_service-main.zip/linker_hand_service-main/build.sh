#!/usr/bin/env bash

# Battery linker hand service build script
# Usage: ./build.sh [Debug|Release]

set -euo pipefail

# Path calculation (assumes the script is in the repository root or under it)
SCRIPT_DIR=$(cd $(dirname "$0") && pwd)
BUILD_DIR="${SCRIPT_DIR}/build"
DEPLOY_DIR="${SCRIPT_DIR}/deploy"

echo "== SCRIPT_DIR: $SCRIPT_DIR"
echo "== BUILD_DIR: $BUILD_DIR"
echo "== DEPLOY_DIR: $DEPLOY_DIR"

# Color output for better readability
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error()   { echo -e "${RED}[ERROR]${NC} $1"; }


# Detect host architecture
detect_arch() {
    local machine_arch=$(uname -m)
    case "$machine_arch" in
        x86_64|amd64) echo "x86_64" ;;
        aarch64|arm64) echo "aarch64" ;;
        *) log_warning "Unknown architecture '$machine_arch', defaulting to x86_64"; echo "x86_64" ;;
    esac
}

ARCH=$(detect_arch)
BUILD_TYPE="Release"

# Optional build type parameter
if [ $# -ge 1 ]; then
    case "$1" in
        Debug|Release)
            BUILD_TYPE="$1"
            ;;
        *)
            log_error "Unsupported build type '$1'. Supported types: Debug, Release"
            show_help
            exit 1
            ;;
    esac
fi

# Show build information
cat <<EOBANNER
==========================================
HiLift Dynamics Build
==========================================
Architecture : $ARCH
Build Type   : $BUILD_TYPE
Build Dir    : $BUILD_DIR
==========================================
EOBANNER


# Change to project root directory
cd "$SCRIPT_DIR"


# Clean and create the build directory (safety checks)
if [ -z "${BUILD_DIR:-}" ] || [ "$BUILD_DIR" = "/" ]; then
    log_error "BUILD_DIR is unset or unsafe ('$BUILD_DIR')"; exit 1
fi

if [ -d "$BUILD_DIR" ]; then
    log_info "Existing build directory '$BUILD_DIR' found, removing..."
    rm -rf "$BUILD_DIR"
fi

if [ -d "$DEPLOY_DIR" ]; then
    log_info "Existing deploy directory '$DEPLOY_DIR' found, removing..."
    rm -rf "$DEPLOY_DIR"
fi


mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# Cross-compilation settings for aarch64
CMAKE_OPTIONS="-DCMAKE_BUILD_TYPE=$BUILD_TYPE -DCMAKE_EXPORT_COMPILE_COMMANDS=ON"
if [ "$ARCH" = "aarch64" ]; then
    log_info "为 aarch64 架构进行交叉编译..."
    source "${SCRIPT_DIR}/scripts/env_aarch64_cross_compile.sh"
    CMAKE_OPTIONS="$CMAKE_OPTIONS -DCMAKE_TOOLCHAIN_FILE=${SCRIPT_DIR}/cmake/aarch64-toolchain.cmake"
fi

# Run CMake configuration
log_info "Configuring CMake..."
if ! cmake $CMAKE_OPTIONS ..; then
    log_error "CMake configuration failed"
    exit 1
fi

# Build
log_info "Building..."
if ! make -j"$(nproc)"; then
    log_error "Build failed"
    exit 1
fi

# Install
log_info "Installing to deploy directory..."
if ! make install; then
    log_error "Installation failed"
    exit 1
fi


cat <<EOFINAL
==========================================
Build Complete
Executable dir  : $DEPLOY_DIR/bin/
Config dir      : $DEPLOY_DIR/config/
Library dir     : $DEPLOY_DIR/lib/
Build Type      : $BUILD_TYPE
Architecture    : $ARCH
==========================================
EOFINAL
